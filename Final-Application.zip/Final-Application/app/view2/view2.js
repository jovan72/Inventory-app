'use strict';


angular.module('myApp.view2', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/view2', {
    templateUrl: 'view2/view2.html',
    controller: 'View2Ctrl'
  });
}])

.controller('View2Ctrl', ['$scope',function($scope) {
  $scope.invoice=false;
  $scope.grn=false;
  $scope.selectedprice;
  $scope.disableqty=true;
  $scope.cartitems=[];
  $scope.items=[
    {"name":"item1","price":700,"location":"USA","onhand":0},
    {"name":"item2","price":400,"location":"UK","onhand":0},
    {"name":"item3","price":600,"location":"SL","onhand":0},
    {"name":"item4","price":800,"location":"AUS","onhand":0}]

  $scope.loadgrn = function(name){	
    $scope.buystyle={
      "color" : "white",
      "background-color" : "blue",
    }
    $scope.sellstyle={
      "color" : "black",
      "background-color" : "white",
    }
    $scope.invoice=false;
    $scope.grn=true;
  }

  $scope.loadinvoice = function(name){	
    $scope.sellstyle={
      "color" : "white",
      "background-color" : "blue",
    }
    $scope.buystyle={
      "color" : "black",
      "background-color" : "white",
    }
    $scope.invoice=true;
    $scope.grn=false;
  }

  $scope.loaditem = function(selectitem){	
    $scope.disableqty=false;
    console.log(selectitem)
    var ItemArr = eval( $scope.items );
    for( var i = 0; i < ItemArr.length; i++ ) {
      if( ItemArr[i].name === selectitem ) {
        $scope.selectedprice=ItemArr[i].price;
      }
    }
  }

  $scope.calculatetotal = function(quentity){	
    $scope.totalamount=$scope.selectedprice*quentity;
  }

  $scope.addcart=function(name,selectedprice,quentity,totalamount){
    
    let item={
      name:name,
      price:selectedprice,
      quentity:quentity,
      totalamount:totalamount
    }
    $scope.cartitems.push(item)
    $scope.selectedprice='';
    $scope.quentity=0;
    $scope.totalamount='';
    $scope.selectitem='';
  }

  $scope.makegrn=function(){
    console.log($scope.cartitems)
    $scope.cartitems=[];
  }
}]);