'use strict';


angular.module('myApp.view1', ['ngRoute'])



.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/view1', {
    templateUrl: 'view1/view1.html',
    controller: 'View1Ctrl'
  });
}])

.controller('View1Ctrl', ['$scope',function($scope) {
  $scope.items=[
    {"name":"item1","price":700,"location":"USA","onhand":0},
    {"name":"item2","price":400,"location":"UK","onhand":0},
    {"name":"item3","price":600,"location":"SL","onhand":0},
    {"name":"item4","price":800,"location":"AUS","onhand":0}]


    $scope.addProduct = function (name,price,location) {
      let item={
        name:name,
        price:price,
        location:location,
        onhand:0
      }
      console.log(item,'sdd')
      $scope.items.push(item)
    }

    $scope.removeRow = function(name){				
      var index = -1;		
      var ItemArr = eval( $scope.items );
      for( var i = 0; i < ItemArr.length; i++ ) {
        if( ItemArr[i].name === name ) {
          index = i;
          break;
        }
      }
      if( index === -1 ) {
        alert( "Something gone wrong" );
      }
      $scope.items.splice( index, 1 );		
    };


}]);

